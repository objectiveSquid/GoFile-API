# Changelog

## 0.0.1
First upload

## 0.0.2
Added more documentation

## 0.0.3
Fixed long description on PyPi

## 0.0.4
Fixed long description on PyPi, again <br>
Added documentation for all functions, and improved existing documentation <br>
Fixed GoFileSession.upload_file

## 0.0.5
Another try at making the actual imports work

## 0.0.6
Last try at making the actual imports work before I jump off a balcony

## 0.0.7
Importing the package now works

## 0.1.0 First full and stable release!
Added uploading a file with options <br>
Added proper exception and response handling <br>
License file included with PyPi repository <br>
Added function to delete content <br>
Fixed a few broken functions
