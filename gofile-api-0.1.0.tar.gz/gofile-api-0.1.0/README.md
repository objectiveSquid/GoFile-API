# GoFile API
### Description
A python library for communicating with the Gofile API.

### Features
Get an available server. <br>
Upload a file. <br>
Create a guest account. <br>
Get contents of a folder. <br>
Create a folder. <br>
Get the account information. <br>
Set option for a content id. This can be a password, whether the content should be public, the content description, <br> and expiration date, tags, or  <br>
Delete files and/or folders.
